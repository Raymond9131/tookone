import React, {Component} from "react";




class Home extends Component {

    state = {
        
    }

    componentDidMount(){
      window.scrollTo(0, 0)
  }
    

   

    
    render() {
       
        
        return (<div>

            Home


        
        
        </div>
        )
    }
}




export default (Home);
